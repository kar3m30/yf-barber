let token=localStorage.getItem("yf_admin_token")||"";
let config=null, scanner=null;

const $=s=>document.querySelector(s);
function cairoToday(){return new Intl.DateTimeFormat("en-CA",{timeZone:"Africa/Cairo"}).format(new Date())}
function authHeaders(){return {"Content-Type":"application/json","Authorization":"Bearer "+token}}

async function login(){
  const r=await fetch("/api/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},
    body:JSON.stringify({username:$("#user").value,password:$("#pass").value})});
  const d=await r.json();
  if(!r.ok){$("#loginErr").textContent=d.error||"فشل الدخول";return}
  token=d.token;localStorage.setItem("yf_admin_token",token);showApp();load();
}
function showApp(){ $("#login").classList.add("hidden"); $("#app").classList.remove("hidden");}
function logout(){localStorage.removeItem("yf_admin_token");location.reload()}
async function load(){
  const r=await fetch("/api/config"); config=await r.json();
  $("#barber").innerHTML=config.barbers.map(b=>`<option value="${b.id}">${b.name}</option>`).join("");
  $("#date").value=cairoToday(); await loadBookings();
}
async function loadBookings(){
  const q=new URLSearchParams({date:$("#date").value,barberId:$("#barber").value});
  const r=await fetch("/api/admin/bookings?"+q,{headers:authHeaders()});
  if(r.status===401)return logout();
  const d=await r.json(); render(d.bookings||[]);
}
function render(items){
  const status={waiting:"بانتظار",called:"مستدعى",done:"تم",cancelled:"ملغي"};
  $("#list").innerHTML=`<div class="row head"><div>الدور</div><div>الاسم</div><div>الهاتف</div><div>الخدمة</div><div>الموعد</div><div>الحالة</div><div>إجراء</div></div>`+
  items.map(b=>`<div class="row">
    <div>${b.queue_number}</div><div>${esc(b.customer_name)}</div><div>${esc(b.phone)}</div>
    <div>${esc(b.service_name)}</div><div>${b.booking_time}</div><div><span class="pill">${status[b.status]||b.status}</span></div>
    <div>
      <button class="action" onclick="setStatus(${b.id},'done')">تم</button>
      <button class="action" onclick="setStatus(${b.id},'cancelled')">إلغاء</button>
    </div>
  </div>`).join("");
}
async function setStatus(id,status){
  await fetch("/api/admin/status",{method:"POST",headers:authHeaders(),body:JSON.stringify({id,status})});
  loadBookings();
}
async function nextBooking(){
  const r=await fetch("/api/admin/next",{method:"POST",headers:authHeaders(),
    body:JSON.stringify({date:$("#date").value,barberId:$("#barber").value})});
  const d=await r.json();
  if(!r.ok){alert(d.error||"حدث خطأ");return}
  if(!d.booking){$("#current").innerHTML="لا يوجد عميل بانتظار الدور.";return}
  const b=d.booking;
  $("#current").innerHTML=`<div class="called">الدور ${b.queue_number} — ${esc(b.customer_name)}</div><div>${esc(b.service_name)} • ${b.booking_time} • ${esc(b.phone)}</div>`;
  loadBookings();
}
async function lookupToken(tokenValue){
  const r=await fetch("/api/admin/qr/"+encodeURIComponent(tokenValue),{headers:authHeaders()});
  const d=await r.json();
  $("#scanResult").innerHTML=r.ok?`<div class="scan-card"><b>${esc(d.booking.customer_name)}</b><br>الدور: ${d.booking.queue_number}<br>الحلاق: ${esc(d.booking.barber_name)}<br>الموعد: ${d.booking.booking_date} — ${d.booking.booking_time}<br>الحالة: ${d.booking.status}</div>`:`<div class="scan-card">${esc(d.error||"الحجز غير موجود")}</div>`;
}
function startScanner(){
  if(scanner)return;
  scanner=new Html5Qrcode("reader");
  scanner.start({facingMode:"environment"},{fps:10,qrbox:{width:230,height:230}},
    async text=>{ 
      let tokenValue=text;
      try{const x=JSON.parse(text);if(x.token)tokenValue=x.token}catch{}
      await lookupToken(tokenValue);
      scanner.stop().then(()=>{scanner=null}).catch(()=>{});
    },
    ()=>{}
  ).catch(e=>{$("#scanResult").innerHTML=`<div class="scan-card">تعذر تشغيل الكاميرا: ${esc(e)}</div>`;scanner=null});
}
function esc(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}

$("#date").addEventListener("change",loadBookings); $("#barber").addEventListener("change",loadBookings);

if(token){
  fetch("/api/admin/bookings?date="+encodeURIComponent(cairoToday()),{headers:authHeaders()}).then(r=>{
    if(r.ok){showApp();load()} else logout()
  }).catch(logout)
}
