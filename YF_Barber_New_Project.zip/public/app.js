const $=s=>document.querySelector(s);
let config=null;
const dateInput=$("#bookingDate");
const today=new Date();
dateInput.min=new Intl.DateTimeFormat("en-CA",{timeZone:"Africa/Cairo"}).format(today);
dateInput.value=dateInput.min;

async function loadConfig(){
  const r=await fetch("/api/config"); config=await r.json();
  $("#barber").innerHTML=config.barbers.map(b=>`<option value="${b.id}">${b.name}</option>`).join("");
  $("#service").innerHTML=config.services.map(s=>`<option value="${s.id}">${s.name} — ${s.price} جنيه</option>`).join("");
  await loadSlots();
}
async function loadSlots(){
  if(!config)return;
  const date=dateInput.value, barber=$("#barber").value;
  if(!date||!barber)return;
  const r=await fetch(`/api/slots?date=${encodeURIComponent(date)}&barberId=${encodeURIComponent(barber)}`);
  const d=await r.json();
  $("#bookingTime").innerHTML=d.slots.map(s=>`<option value="${s.time}" ${s.full?"disabled":""}>${s.time}${s.full?" — مكتمل":` — ${s.used}/2`}</option>`).join("");
  const first=d.slots.find(s=>!s.full); if(first) $("#bookingTime").value=first.time;
}
$("#barber").addEventListener("change",loadSlots); dateInput.addEventListener("change",loadSlots);

$("#bookingForm").addEventListener("submit",async e=>{
  e.preventDefault(); $("#error").textContent="";
  const barber=config.barbers.find(x=>x.id===$("#barber").value);
  const service=config.services.find(x=>x.id===$("#service").value);
  const payload={
    customerName:$("#customerName").value.trim(), phone:$("#phone").value.trim(),
    barberId:barber.id, serviceId:service.id, bookingDate:dateInput.value,
    bookingTime:$("#bookingTime").value
  };
  const r=await fetch("/api/bookings",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload)});
  const d=await r.json();
  if(!r.ok){$("#error").textContent=d.error||"حدث خطأ";await loadSlots();return;}
  showTicket(d.booking);
});
function showTicket(b){
  $("#bookingPanel").classList.add("hidden");
  const t=$("#ticket"); t.classList.remove("hidden");
  t.innerHTML=`<h2>تم تأكيد الحجز ✓</h2>
  <div class="sub">احتفظ بهذا الكرت وأظهر رمز QR عند الوصول</div>
  <div class="queue">دورك: ${b.queueNumber}</div>
  <img class="qr" src="${b.qrDataUrl}" alt="QR">
  <div class="ticket-grid">
    <div class="ticket-item"><small>الاسم</small><b>${esc(b.customerName)}</b></div>
    <div class="ticket-item"><small>الهاتف</small><b>${esc(b.phone)}</b></div>
    <div class="ticket-item"><small>الحلاق</small><b>${esc(b.barberName)}</b></div>
    <div class="ticket-item"><small>الخدمة</small><b>${esc(b.serviceName)}</b></div>
    <div class="ticket-item"><small>السعر</small><b>${b.price} جنيه</b></div>
    <div class="ticket-item"><small>التاريخ</small><b>${b.bookingDate}</b></div>
    <div class="ticket-item"><small>الموعد</small><b>${b.bookingTime}</b></div>
  </div>
  <button class="primary" onclick="location.reload()">حجز جديد</button>`;
  window.scrollTo({top:t.offsetTop-15,behavior:"smooth"});
}
function esc(v){return String(v).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
loadConfig();
