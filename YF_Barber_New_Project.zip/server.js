const express = require("express");
const crypto = require("crypto");
const QRCode = require("qrcode");
const { createClient } = require("@libsql/client");

const app = express();
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 3000;
const ADMIN_USER = process.env.ADMIN_USER || "admin";
const ADMIN_PASS = process.env.ADMIN_PASS || "9621";
const SESSION_SECRET = process.env.SESSION_SECRET || "YF_CHANGE_THIS_SECRET_2026";
const TURSO_DATABASE_URL = process.env.TURSO_DATABASE_URL;
const TURSO_AUTH_TOKEN = process.env.TURSO_AUTH_TOKEN;

if (!TURSO_DATABASE_URL || !TURSO_AUTH_TOKEN) {
  console.error("Missing TURSO_DATABASE_URL or TURSO_AUTH_TOKEN");
}

const db = createClient({
  url: TURSO_DATABASE_URL || "file:local.db",
  authToken: TURSO_AUTH_TOKEN
});

const BARBERS = [
  { id: "yousef-farouk", name: "يوسف فاروق" },
  { id: "yousef-small", name: "يوسف الصغير" }
];

const SERVICES = [
  { id: "hair-beard", name: "حلاقة شعر ودقن", price: 120 },
  { id: "beard", name: "حلاقة دقن", price: 70 },
  { id: "full", name: "حلاقة كاملة", price: 250 }
];

function normalizeArabic(s) {
  return String(s ?? "").trim();
}

function validDate(date) {
  return /^\d{4}-\d{2}-\d{2}$/.test(date);
}

function validTime(time) {
  return /^([01]\d|2[0-3]):([0-5]\d)$/.test(time);
}

function timeSlots() {
  const out = [];
  for (let h = 12; h <= 24; h++) {
    for (let m = 0; m < 60; m += 30) {
      if (h === 24 && m > 30) continue;
      const hh = h === 24 ? 0 : h;
      out.push(`${String(hh).padStart(2, "0")}:${String(m).padStart(2, "0")}`);
    }
  }
  out.push("01:00");
  return out;
}

function sign(value) {
  return crypto.createHmac("sha256", SESSION_SECRET).update(value).digest("hex");
}

function makeSession() {
  const payload = Buffer.from(JSON.stringify({
    u: ADMIN_USER,
    exp: Date.now() + 1000 * 60 * 60 * 12
  })).toString("base64url");
  return `${payload}.${sign(payload)}`;
}

function validSession(token) {
  try {
    if (!token) return false;
    const [payload, signature] = token.split(".");
    if (!payload || !signature) return false;
    if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(sign(payload)))) return false;
    const data = JSON.parse(Buffer.from(payload, "base64url").toString());
    return data.u === ADMIN_USER && data.exp > Date.now();
  } catch {
    return false;
  }
}

function adminOnly(req, res, next) {
  const token = String(req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!validSession(token)) return res.status(401).json({ error: "غير مصرح" });
  next();
}

async function initDb() {
  await db.batch([
    { sql: `CREATE TABLE IF NOT EXISTS bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT NOT NULL,
      phone TEXT NOT NULL,
      barber_id TEXT NOT NULL,
      barber_name TEXT NOT NULL,
      service_id TEXT NOT NULL,
      service_name TEXT NOT NULL,
      price INTEGER NOT NULL,
      booking_date TEXT NOT NULL,
      booking_time TEXT NOT NULL,
      queue_number INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'waiting',
      qr_token TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL
    )` },
    { sql: `CREATE INDEX IF NOT EXISTS idx_bookings_date_barber_time
      ON bookings(booking_date, barber_id, booking_time)` },
    { sql: `CREATE INDEX IF NOT EXISTS idx_bookings_qr ON bookings(qr_token)` },
    { sql: `CREATE INDEX IF NOT EXISTS idx_bookings_queue
      ON bookings(booking_date, barber_id, status, queue_number)` }
  ]);
}

async function getCapacity(date, barberId, time) {
  const r = await db.execute({
    sql: `SELECT COUNT(*) AS c FROM bookings
          WHERE booking_date = ? AND barber_id = ? AND booking_time = ?
          AND status != 'cancelled'`,
    args: [date, barberId, time]
  });
  return Number(r.rows[0]?.c || 0);
}

async function createBooking(data) {
  // Serialized transaction prevents two requests from taking the same last seat.
  await db.execute("BEGIN IMMEDIATE");
  try {
    const capacity = await getCapacity(data.bookingDate, data.barberId, data.bookingTime);
    if (capacity >= 2) {
      await db.execute("ROLLBACK");
      return { error: "هذا الموعد مكتمل لهذا الحلاق. اختر موعداً آخر.", code: "FULL" };
    }

    const maxQ = await db.execute({
      sql: `SELECT COALESCE(MAX(queue_number), 0) AS q
            FROM bookings WHERE booking_date = ? AND barber_id = ?`,
      args: [data.bookingDate, data.barberId]
    });

    const queue = Number(maxQ.rows[0]?.q || 0) + 1;
    const token = crypto.randomBytes(18).toString("hex");

    await db.execute({
      sql: `INSERT INTO bookings
        (customer_name, phone, barber_id, barber_name, service_id, service_name,
         price, booking_date, booking_time, queue_number, status, qr_token, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'waiting', ?, ?)`,
      args: [
        data.customerName, data.phone, data.barberId, data.barberName,
        data.serviceId, data.serviceName, data.price, data.bookingDate,
        data.bookingTime, queue, token, new Date().toISOString()
      ]
    });

    await db.execute("COMMIT");
    return { booking: { ...data, queueNumber: queue, qrToken: token } };
  } catch (e) {
    try { await db.execute("ROLLBACK"); } catch {}
    throw e;
  }
}

app.get("/api/config", (req, res) => {
  res.json({ barbers: BARBERS, services: SERVICES, slots: timeSlots() });
});

app.get("/api/slots", async (req, res) => {
  try {
    const date = String(req.query.date || "");
    const barberId = String(req.query.barberId || "");
    if (!validDate(date) || !BARBERS.some(b => b.id === barberId)) {
      return res.status(400).json({ error: "بيانات غير صحيحة" });
    }

    const rows = await db.execute({
      sql: `SELECT booking_time, COUNT(*) AS used
            FROM bookings
            WHERE booking_date = ? AND barber_id = ? AND status != 'cancelled'
            GROUP BY booking_time`,
      args: [date, barberId]
    });

    const counts = Object.fromEntries(rows.rows.map(r => [r.booking_time, Number(r.used)]));
    res.json({
      slots: timeSlots().map(time => ({
        time,
        used: counts[time] || 0,
        full: (counts[time] || 0) >= 2
      }))
    });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "تعذر تحميل المواعيد" });
  }
});

app.post("/api/bookings", async (req, res) => {
  try {
    const customerName = normalizeArabic(req.body.customerName);
    const phone = normalizeArabic(req.body.phone);
    const barberId = normalizeArabic(req.body.barberId);
    const serviceId = normalizeArabic(req.body.serviceId);
    const bookingDate = normalizeArabic(req.body.bookingDate);
    const bookingTime = normalizeArabic(req.body.bookingTime);

    const barber = BARBERS.find(b => b.id === barberId);
    const service = SERVICES.find(s => s.id === serviceId);

    if (!customerName || customerName.length < 2) return res.status(400).json({ error: "اكتب اسم العميل" });
    if (!phone || phone.length < 7) return res.status(400).json({ error: "اكتب رقم الهاتف بشكل صحيح" });
    if (!barber || !service) return res.status(400).json({ error: "اختر الحلاق والخدمة" });
    if (!validDate(bookingDate) || !validTime(bookingTime) || !timeSlots().includes(bookingTime)) {
      return res.status(400).json({ error: "اختر تاريخاً وموعداً صحيحاً" });
    }

    const result = await createBooking({
      customerName, phone, barberId, barberName: barber.name,
      serviceId, serviceName: service.name, price: service.price,
      bookingDate, bookingTime
    });

    if (result.error) return res.status(409).json({ error: result.error });
    const booking = result.booking;

    const qrData = JSON.stringify({
      token: booking.qrToken,
      name: booking.customerName,
      date: booking.bookingDate,
      time: booking.bookingTime,
      barber: booking.barberName,
      queue: booking.queueNumber
    });
    booking.qrDataUrl = await QRCode.toDataURL(qrData, { width: 320, margin: 2 });

    res.status(201).json({ booking });
  } catch (e) {
    console.error("BOOKING_ERROR", e);
    res.status(500).json({ error: "تعذر تسجيل الحجز. حاول مرة أخرى." });
  }
});

app.post("/api/admin/login", (req, res) => {
  const username = normalizeArabic(req.body.username).toLowerCase();
  const password = String(req.body.password || "");
  if (username !== ADMIN_USER.toLowerCase() || password !== ADMIN_PASS) {
    return res.status(401).json({ error: "اسم المستخدم أو كلمة المرور غير صحيحة" });
  }
  res.json({ token: makeSession() });
});

app.get("/api/admin/bookings", adminOnly, async (req, res) => {
  try {
    const date = String(req.query.date || "");
    const barberId = String(req.query.barberId || "");
    let sql = `SELECT * FROM bookings WHERE 1=1`;
    const args = [];
    if (validDate(date)) { sql += " AND booking_date = ?"; args.push(date); }
    if (barberId) { sql += " AND barber_id = ?"; args.push(barberId); }
    sql += " ORDER BY booking_date ASC, booking_time ASC, queue_number ASC";
    const result = await db.execute({ sql, args });
    res.json({ bookings: result.rows });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "تعذر تحميل الحجوزات" });
  }
});

app.post("/api/admin/status", adminOnly, async (req, res) => {
  try {
    const id = Number(req.body.id);
    const status = String(req.body.status || "");
    if (!Number.isInteger(id) || !["waiting", "called", "done", "cancelled"].includes(status)) {
      return res.status(400).json({ error: "بيانات غير صحيحة" });
    }
    await db.execute({ sql: "UPDATE bookings SET status = ? WHERE id = ?", args: [status, id] });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: "تعذر تحديث الحالة" });
  }
});

app.post("/api/admin/next", adminOnly, async (req, res) => {
  try {
    const date = String(req.body.date || "");
    const barberId = String(req.body.barberId || "");
    if (!validDate(date) || !barberId) return res.status(400).json({ error: "اختر التاريخ والحلاق" });

    await db.execute("BEGIN IMMEDIATE");
    try {
      await db.execute({
        sql: `UPDATE bookings SET status = 'done'
              WHERE booking_date = ? AND barber_id = ? AND status = 'called'`,
        args: [date, barberId]
      });

      const next = await db.execute({
        sql: `SELECT * FROM bookings
              WHERE booking_date = ? AND barber_id = ? AND status = 'waiting'
              ORDER BY queue_number ASC LIMIT 1`,
        args: [date, barberId]
      });

      if (!next.rows.length) {
        await db.execute("COMMIT");
        return res.json({ booking: null });
      }

      const booking = next.rows[0];
      await db.execute({
        sql: "UPDATE bookings SET status = 'called' WHERE id = ?",
        args: [booking.id]
      });
      await db.execute("COMMIT");
      res.json({ booking: { ...booking, status: "called" } });
    } catch (e) {
      try { await db.execute("ROLLBACK"); } catch {}
      throw e;
    }
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "تعذر استدعاء التالي" });
  }
});

app.get("/api/admin/qr/:token", adminOnly, async (req, res) => {
  try {
    const result = await db.execute({
      sql: "SELECT * FROM bookings WHERE qr_token = ? LIMIT 1",
      args: [String(req.params.token)]
    });
    if (!result.rows.length) return res.status(404).json({ error: "الحجز غير موجود" });
    res.json({ booking: result.rows[0] });
  } catch (e) {
    res.status(500).json({ error: "تعذر قراءة رمز الحجز" });
  }
});

app.use(express.static("public"));

app.get("*", (req, res) => {
  res.sendFile(require("path").join(__dirname, "public", "index.html"));
});

initDb().catch(err => console.error("DB_INIT_ERROR", err));

module.exports = app;

if (require.main === module) {
  app.listen(PORT, () => console.log(`YF Barber running on ${PORT}`));
}
